// ITEM 표준 인터페이스 — Q-295
var ITEM = {
  type: "ox",
  answer: "X",
  explanation: "정답은 504이므로 틀립니다. 289 + 215 = 504입니다. 일의 자리에서 받아올림 발생, 십의 자리에서도 받아올림이 발생하는 연속 올림 문제입니다.",
  selected: null
};

function getResponse() { return ITEM.selected; }
function getResult() {
  var correct = ITEM.type==="essay" ? true : String(ITEM.selected)===String(ITEM.answer);
  return { correct: correct, response: ITEM.selected, answer: ITEM.answer, duration: _timer };
}
function submitAnswer() {
  var r = getResult();
  var fb = document.getElementById("feedback");
  var fbResult = document.getElementById("fb-result");
  var fbBody = document.getElementById("fb-explain-body");
  fb.style.display = "flex";
  fbResult.className = "fb-result " + (r.correct ? "fc" : "fw");
  fbResult.innerHTML = (r.correct ? "🎉" : "❌") + " " + (r.correct ? "정답입니다!" : "오답입니다. 정답: " + ITEM.answer);
  // 문장 단위 줄바꿈: 마침표/물음표/느낌표 뒤에서 줄바꿈
  var lines = ITEM.explanation.replace(/([.?!。])s*/g, "$1\n").split("\n").filter(function(l){return l.trim();});
  fbBody.innerHTML = lines.map(function(l){return "<p style='margin:0 0 6px 0'>" + l.trim() + "</p>";}).join("");
  _stopTimer();
}
function confirmExplanation() {
  var btn = document.querySelector(".btn-view-confirm");
  if(btn) { btn.textContent = "✅ 확인 완료"; btn.disabled = true; btn.style.opacity = "0.5"; }
}
function resetItem() {
  ITEM.selected = null;
  document.getElementById("feedback").style.display = "none";
  document.querySelectorAll(".option,.ox-btn").forEach(function(el){el.classList.remove("selected","correct","wrong");});
  var fi = document.getElementById("fill-input"); if(fi) fi.value="";
  var ei = document.getElementById("essay-input"); if(ei) ei.value="";
  if(typeof closeMathPad==="function") closeMathPad();
  _startTimer();
}

// Math Pad (숫자 패드)
function openMathPad() {
  var pad = document.getElementById("math-pad");
  if(pad) pad.style.display = "block";
  var btn = document.getElementById("math-toggle-btn");
  if(btn) { btn.textContent = "▼ 숫자패드 닫기"; btn.classList.add("active"); }
}
function closeMathPad() {
  var pad = document.getElementById("math-pad");
  if(pad) pad.style.display = "none";
  var btn = document.getElementById("math-toggle-btn");
  if(btn) { btn.textContent = "🔢 숫자패드"; btn.classList.remove("active"); }
}
function toggleMathPad() {
  var pad = document.getElementById("math-pad");
  if(pad && pad.style.display === "none") openMathPad(); else closeMathPad();
}
function mathInput(ch) {
  var fi = document.getElementById("fill-input");
  if(fi) { fi.value += ch; ITEM.selected = fi.value; fi.focus(); }
}
function mathBackspace() {
  var fi = document.getElementById("fill-input");
  if(fi) { fi.value = fi.value.slice(0,-1); ITEM.selected = fi.value; fi.focus(); }
}
function mathClear() {
  var fi = document.getElementById("fill-input");
  if(fi) { fi.value = ""; ITEM.selected = ""; fi.focus(); }
}

// MathType API (common-mathtype.js)
// 컨테이너에서 common-mathtype.js를 로딩하면 showMathType/showHandType/closeMathType 함수 사용 가능
function openMathTypeInput() {
  var toolbar = "elementary";
  if(typeof showMathType === "function") {
    showMathType("mathtype-fill", document.getElementById("mathtype-fill").innerHTML || "", toolbar);
    // OctoPlayer 환경이 아닌 경우 2초 후 안내
    var _mtTimeout = setTimeout(function() {
      var ec = document.getElementById("editorContainer");
      if(!ec || ec.style.display === "none" || ec.offsetHeight === 0) {
        var msgEl = document.createElement("div");
        msgEl.className = "mathtype-msg";
        msgEl.textContent = "ℹ️ MathType는 OctoPlayer 환경에서 동작합니다. 숫자패드를 이용하세요.";
        var wrap = document.querySelector(".fill-math-wrap");
        if(wrap && !wrap.querySelector(".mathtype-msg")) wrap.appendChild(msgEl);
        setTimeout(function(){ if(msgEl.parentNode) msgEl.parentNode.removeChild(msgEl); }, 3000);
      }
    }, 1500);
  }
}

// Timer
var _timer=0, _timerInterval=null;
function _startTimer(){_timer=0;clearInterval(_timerInterval);_timerInterval=setInterval(function(){_timer++;var m=Math.floor(_timer/60);var s=_timer%60;document.getElementById("timer-display").textContent=m+":"+String(s).padStart(2,"0");},1000);}
function _stopTimer(){clearInterval(_timerInterval);}

// Init
document.addEventListener("DOMContentLoaded", function(){
  _startTimer();
  document.querySelectorAll(".option").forEach(function(el){
    el.addEventListener("click",function(){
      document.querySelectorAll(".option").forEach(function(o){o.classList.remove("selected");});
      el.classList.add("selected");
      ITEM.selected = el.dataset.idx;
    });
  });
  document.querySelectorAll(".ox-btn").forEach(function(el){
    el.addEventListener("click",function(){
      document.querySelectorAll(".ox-btn").forEach(function(o){o.classList.remove("selected");});
      el.classList.add("selected");
      ITEM.selected = el.dataset.val;
    });
  });
  var fi=document.getElementById("fill-input");
  if(fi) fi.addEventListener("input",function(){ITEM.selected=fi.value;});
  var ei=document.getElementById("essay-input");
  if(ei) ei.addEventListener("input",function(){ITEM.selected=ei.value;});
});