// octo-bridge.js V4 — OctoPlayer 뷰어-콘텐츠 연동 브릿지
// 콘텐츠(iframe/html) ↔ 뷰어(OctoPlayer) ↔ 컨테이너
// iframe타입 + html타입 양쪽 모두 지원

(function() {
  "use strict";
  var LOG = "[octo-bridge]";

  var _state = {
    userId: null,
    contentId: "Q-295",
    contentTag: {},
    startTime: null,
    currentPage: 1
  };

  // ============================================================
  // 1. postMessage 전송 (iframe/html 양쪽 대응)
  // ============================================================
  function send(msg) {
    try {
      if (window.parent && window.parent !== window) {
        window.parent.postMessage(msg, "*");
      }
    } catch(e) { console.warn(LOG, "send 실패:", e); }
  }

  // ============================================================
  // 2. 현재 페이지 + 높이 알림 (iframe/html 양쪽 전송)
  // ============================================================
  function notifyCurrentPage() {
    var h = document.body ? document.body.scrollHeight : 800;
    send({ type: "iframeCurrentPage", data: _state.currentPage, height: h });
    console.log(LOG, "iframeCurrentPage:", _state.currentPage, "h=" + h);
  }

  // 높이 변경 감지 → 자동 재전송
  var _lastH = 0;
  setInterval(function() {
    var h = document.body ? document.body.scrollHeight : 0;
    if (h !== _lastH && h > 0) { _lastH = h; notifyCurrentPage(); }
  }, 500);

  // ============================================================
  // 3. 메시지 수신 (뷰어 → 콘텐츠)
  // ============================================================
  window.addEventListener("message", function(event) {
    if (!event.data) return;
    var msg = event.data;
    var type = msg.type;
    if (!type) return;

    console.log(LOG, "수신:", type, JSON.stringify(msg).substring(0, 150));

    switch(type) {
      case "sendRestoreData":
        if (msg.contentId) _state.contentId = msg.contentId;
        if (msg.contentTag) _state.contentTag = msg.contentTag;
        doRestore(msg.data);
        break;

      case "sendUserId":
        _state.userId = msg.data;
        console.log(LOG, "userId 수신:", _state.userId);
        break;

      case "nextPage":
        console.log(LOG, "nextPage 수신");
        notifyCurrentPage(); // 단일 문항 — 현재 페이지 응답
        break;

      case "prevPage":
        console.log(LOG, "prevPage 수신");
        notifyCurrentPage();
        break;

      case "terminated":
        console.log(LOG, "terminated 수신");
        emitXapi("left", { duration: getDuration() });
        if (typeof _stopTimer === "function") _stopTimer();
        // iframe 타입: deinit
        send({ type: "deinit" });
        // html 타입: terminated (self)
        console.log(LOG, "deinit/terminated 응답 완료");
        break;

      case "confirmMathType":
        onMathTypeResult(msg.data || msg);
        break;

      case "closeMathType":
        break;

      default:
        break;
    }
  });

  // ============================================================
  // 4. RESTORE 복원
  // ============================================================
  function doRestore(data) {
    if (!data) { console.log(LOG, "restore 데이터 없음 (null)"); return; }
    if (typeof data === "object" && Object.keys(data).length === 0) {
      console.log(LOG, "빈 restore — 신규 학습");
      return;
    }
    console.log(LOG, "restore 시작:", JSON.stringify(data).substring(0, 300));

    try {
      // ITEM 객체에 선택값 복원
      if (typeof ITEM !== "undefined" && data.selected != null) {
        ITEM.selected = data.selected;
        console.log(LOG, "ITEM.selected 복원:", data.selected);
      }

      // 객관식 복원
      var opts = document.querySelectorAll(".option");
      if (opts.length > 0 && data.selected) {
        opts.forEach(function(el) {
          el.classList.remove("selected");
          if (el.dataset.idx === String(data.selected)) {
            el.classList.add("selected");
            console.log(LOG, "객관식 복원:", data.selected);
          }
        });
      }

      // OX 복원
      var oxBtns = document.querySelectorAll(".ox-btn");
      if (oxBtns.length > 0 && data.selected) {
        oxBtns.forEach(function(el) {
          el.classList.remove("selected");
          if (el.dataset.val === String(data.selected)) {
            el.classList.add("selected");
            console.log(LOG, "OX 복원:", data.selected);
          }
        });
      }

      // 빈칸채우기 복원
      var fi = document.getElementById("fill-input");
      if (fi && data.selected) {
        fi.value = data.selected;
        console.log(LOG, "빈칸 복원:", data.selected);
      }

      // 서술형 복원
      var ei = document.getElementById("essay-input");
      if (ei && data.selected) {
        ei.value = data.selected;
        console.log(LOG, "서술형 복원:", String(data.selected).substring(0, 50));
      }

      // 타이머 복원
      if (typeof data.elapsed === "number" && typeof _timer !== "undefined") {
        _timer = data.elapsed;
      }

      // 제출 상태 복원
      if (data.submitted && typeof submitAnswer === "function") {
        setTimeout(function() {
          submitAnswer();
          console.log(LOG, "제출 상태 복원됨");
        }, 200);
      }

      console.log(LOG, "restore 완료");
      setTimeout(notifyCurrentPage, 300); // 높이 변경 반영
    } catch(e) {
      console.warn(LOG, "restore 실패:", e);
    }
  }

  function buildRestoreData() {
    return {
      selected: (typeof ITEM !== "undefined") ? ITEM.selected : null,
      elapsed: (typeof _timer !== "undefined") ? _timer : 0,
      submitted: !!(document.getElementById("feedback") &&
                    document.getElementById("feedback").style.display !== "none"),
      timestamp: new Date().toISOString()
    };
  }

  function getDuration() {
    return "PT" + ((typeof _timer !== "undefined") ? _timer : 0) + "S";
  }

  // ============================================================
  // 5. xAPI (sendLogToContainer)
  // ============================================================
  function emitXapi(verb, ext) {
    // OctoPlayer 내부 포맷과 충돌 방지:
    // sendLogToContainer는 completed만 전송 (가장 핵심 이벤트)
    // started/left/reset은 OctoPlayer가 자체 처리
    if (verb !== "completed") {
      console.log(LOG, "xAPI (로컬):", verb);
      return;
    }

    try {
      var restoreObj = {};
      restoreObj[_state.contentId] = buildRestoreData();

      var responseObj = {};
      responseObj[_state.contentId] = {
        selected: (typeof ITEM !== "undefined") ? ITEM.selected : null,
        correct: ext ? !!ext.success : false
      };

      var payload = {
        restore: restoreObj,
        xAPI: {
          verb: verb,
          object: { id: _state.contentId },
          result: ext ? { duration: ext.duration || "", extensions: ext } : {},
          response: responseObj,
          context: { extensions: { "lcms/conts-id": _state.contentId } }
        },
        timestamp: new Date().toISOString()
      };

      send({ type: "sendLogToContainer", data: payload });
      console.log(LOG, "xAPI (전송):", verb);
    } catch(e) {
      console.warn(LOG, "xAPI 전송 실패:", verb, e.message);
    }
  }

  // ============================================================
  // 6. MathType — 기존 함수가 있으면 안 건드림
  // ============================================================
  // common-mathtype.js가 이미 window에 주입했을 수 있음
  var _origShowMathType = window.showMathType;
  var _origShowHandType = window.showHandType;
  var _origCloseMathType = window.closeMathType;
  var _origConfirmMathType = window.confirmMathType;

  function findMathTypeFn(fnName) {
    // 0차: window에 이미 존재 (뷰어/컨테이너가 주입)
    if (fnName === "showMathType" && typeof _origShowMathType === "function") return _origShowMathType;
    if (fnName === "showHandType" && typeof _origShowHandType === "function") return _origShowHandType;
    if (fnName === "closeMathType" && typeof _origCloseMathType === "function") return _origCloseMathType;
    if (fnName === "confirmMathType" && typeof _origConfirmMathType === "function") return _origConfirmMathType;

    // 1차: parent.parent (컨테이너)
    try {
      if (window.parent && window.parent.parent &&
          window.parent.parent !== window &&
          typeof window.parent.parent[fnName] === "function") {
        return function() { window.parent.parent[fnName].apply(window.parent.parent, arguments); };
      }
    } catch(e) {}

    // 2차: parent (뷰어)
    try {
      if (window.parent && window.parent !== window &&
          typeof window.parent[fnName] === "function") {
        return function() { window.parent[fnName].apply(window.parent, arguments); };
      }
    } catch(e) {}

    // 3차: top
    try {
      if (window.top && window.top !== window &&
          typeof window.top[fnName] === "function") {
        return function() { window.top[fnName].apply(window.top, arguments); };
      }
    } catch(e) {}

    return null;
  }

  window.showMathType = function(id, val, toolbar) {
    var fn = findMathTypeFn("showMathType");
    if (fn) {
      fn(id || "mathtype-fill", val || "", toolbar || "elementary");
      console.log(LOG, "showMathType 호출 성공");
    } else {
      console.warn(LOG, "showMathType 함수를 찾을 수 없음 — postMessage 시도");
      send({ type: "showMathType", id: id, value: val, toolbar: toolbar });
    }
  };
  window.showHandType = function(id, val, toolbar) {
    var fn = findMathTypeFn("showHandType");
    if (fn) { fn(id || "mathtype-fill", val || "", toolbar || "elementary"); }
    else { send({ type: "showHandType", id: id, value: val, toolbar: toolbar }); }
  };
  window.closeMathType = function() {
    var fn = findMathTypeFn("closeMathType");
    if (fn) { fn(); } else { send({ type: "closeMathType" }); }
  };
  window.confirmMathType = function() {
    var fn = findMathTypeFn("confirmMathType");
    if (fn) { fn(); } else { send({ type: "confirmMathType" }); }
  };

  function onMathTypeResult(data) {
    if (!data) return;
    console.log(LOG, "MathType 결과:", data);
    var target = document.getElementById(data.id);
    if (target) target.innerHTML = data.value || "";
    var fi = document.getElementById("fill-input");
    if (fi && data.value) {
      fi.value = data.value.replace(/<[^>]*>/g, "");
      if (typeof ITEM !== "undefined") ITEM.selected = fi.value;
    }
    setTimeout(notifyCurrentPage, 200);
  }

  // ============================================================
  // 7. 함수 래핑 (비침습)
  // ============================================================
  function wrap(fnName, before, after) {
    if (typeof window[fnName] === "function") {
      var orig = window[fnName];
      window[fnName] = function() {
        if (before) before.apply(this, arguments);
        var r = orig.apply(this, arguments);
        if (after) after.apply(this, arguments);
        return r;
      };
    }
  }

  wrap("submitAnswer", null, function() {
    var r = (typeof getResult === "function") ? getResult() : {};
    emitXapi("completed", {
      skip: false, "req-act-cnt": 1, "com-act-cnt": 1,
      "crt-cnt": r.correct ? 1 : 0, "incrt-cnt": r.correct ? 0 : 1,
      "crt-rt": r.correct ? "1.00" : "0.00",
      success: !!r.correct, duration: getDuration()
    });
    setTimeout(notifyCurrentPage, 300); // 피드백 표시 후 높이 갱신
  });

  wrap("resetItem", function() {
    emitXapi("reset", {});
  }, function() {
    setTimeout(notifyCurrentPage, 300);
  });

  // ============================================================
  // 8. 초기화
  // ============================================================
  function init() {
    console.log(LOG, "==== 초기화 시작 ====");
    console.log(LOG, "contentId:", _state.contentId);
    console.log(LOG, "parent === self:", window.parent === window);
    console.log(LOG, "ITEM 존재:", typeof ITEM !== "undefined");

    // === OctoPlayer 환경 진단 ===
    diagnose();

    _state.startTime = new Date().toISOString();

    // 현재 페이지 알림 (최우선)
    notifyCurrentPage();

    // userId 요청
    send({ type: "requestUserId" });
    console.log(LOG, "requestUserId 전송");

    // restore 요청
    send({ type: "requestRestoreData" });
    console.log(LOG, "requestRestoreData 전송");

    // 1초, 3초 후 재시도 (뷰어 초기화 지연 대비)
    setTimeout(function() {
      console.log(LOG, "지연 재요청 (1초)");
      send({ type: "requestUserId" });
      send({ type: "requestRestoreData" });
    }, 1000);
    setTimeout(function() {
      console.log(LOG, "지연 재요청 (3초)");
      send({ type: "requestRestoreData" });
      diagnose();
    }, 3000);

    // beforeunload
    window.addEventListener("beforeunload", function() {
      // left는 sendLogToContainer 안 보냄 (에러 방지)
    });

    console.log(LOG, "==== 초기화 완료 ====");
  }

  // === OctoPlayer 환경 진단 함수 ===
  function diagnose() {
    console.log(LOG, "=== 환경 진단 시작 ===");

    // 1. iframe 구조 확인
    console.log(LOG, "[진단] window.parent === window:", window.parent === window);
    console.log(LOG, "[진단] window.top === window:", window.top === window);
    try {
      console.log(LOG, "[진단] parent.parent 접근:", window.parent && window.parent.parent ? "가능" : "불가");
    } catch(e) { console.log(LOG, "[진단] parent.parent 접근: cross-origin 차단"); }

    // 2. MathType 함수 탐색
    var mathLocations = [];
    try { if (typeof window.showMathType === "function") mathLocations.push("window"); } catch(e) {}
    try { if (window.parent && typeof window.parent.showMathType === "function") mathLocations.push("parent"); } catch(e) {}
    try { if (window.parent && window.parent.parent && typeof window.parent.parent.showMathType === "function") mathLocations.push("parent.parent"); } catch(e) {}
    try { if (window.top && typeof window.top.showMathType === "function") mathLocations.push("top"); } catch(e) {}
    console.log(LOG, "[진단] showMathType 위치:", mathLocations.length > 0 ? mathLocations.join(", ") : "❌ 어디에도 없음");

    // 3. containerInterface 존재 확인
    try { console.log(LOG, "[진단] containerInterface:", typeof window.containerInterface !== "undefined" ? "있음" : "없음"); } catch(e) {}
    try { console.log(LOG, "[진단] parent.containerInterface:", typeof window.parent.containerInterface !== "undefined" ? "있음" : "없음"); } catch(e) { console.log(LOG, "[진단] parent.containerInterface: 접근불가"); }
    try { console.log(LOG, "[진단] parent.parentContainer:", typeof window.parent.parentContainer !== "undefined" ? "있음" : "없음"); } catch(e) { console.log(LOG, "[진단] parent.parentContainer: 접근불가"); }

    // 4. 콘텐츠 인터페이스 확인
    try { console.log(LOG, "[진단] parent.octoplayer-content-interface:", window.parent.document ? "same-origin" : "cross-origin"); } catch(e) { console.log(LOG, "[진단] parent: cross-origin"); }

    console.log(LOG, "=== 환경 진단 완료 ===");
    console.log(LOG, "⚠️ [진단 결과] showMathType이 '❌ 어디에도 없음'이면:");
    console.log(LOG, "   → OctoPlayer 팀에 common-mathtype.js 로딩 위치 확인 필요");
    console.log(LOG, "⚠️ [진단 결과] 'sendRestoreData' 수신 로그가 없으면:");
    console.log(LOG, "   → OctoPlayer가 이 콘텐츠 타입을 인식하지 못하고 있음");
    console.log(LOG, "   → loadContents 시 type/contentId 설정 확인 필요");
  }

  // 진단 함수를 글로벌로 노출 (콘솔에서 수동 실행 가능)
  window._octoBridgeDiagnose = diagnose;

  // item.js의 DOMContentLoaded 핸들러가 먼저 실행된 후 init
  if (document.readyState === "complete") {
    init();
  } else {
    window.addEventListener("load", init);
  }
})();